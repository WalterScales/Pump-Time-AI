import { 
  PhoneCall, 
  Calendar, 
  MessageSquare, 
  Star, 
  TrendingUp, 
  CheckCircle2, 
  Clock, 
  ShieldCheck,
  ArrowRight,
  Menu,
  X,
  Smartphone,
  BarChart3,
  Users,
  Link,
  Zap,
  Database,
  RefreshCw
} from 'lucide-react';
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';

// --- Components ---

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`fixed top-0 w-full z-50 transition-all duration-300 ${isScrolled ? 'bg-white/90 backdrop-blur-md shadow-sm py-3' : 'bg-transparent py-5'}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <div className="bg-blue-600 p-1.5 rounded-lg">
            <TrendingUp className="text-white w-6 h-6" />
          </div>
          <span className="text-xl font-bold tracking-tight text-slate-900">Pump Time <span className="text-blue-600">AI</span></span>
        </div>
        
        <div className="hidden md:flex items-center gap-8">
          <a href="#problem" className="text-sm font-medium text-slate-600 hover:text-blue-600 transition-colors">Problem</a>
          <a href="#solution" className="text-sm font-medium text-slate-600 hover:text-blue-600 transition-colors">Solution</a>
          <a href="#how-it-works" className="text-sm font-medium text-slate-600 hover:text-blue-600 transition-colors">How It Works</a>
          <a href="#features" className="text-sm font-medium text-slate-600 hover:text-blue-600 transition-colors">Features</a>
          <a href="#integrations" className="text-sm font-medium text-slate-600 hover:text-blue-600 transition-colors">Integrations</a>
          <a href="#pricing" className="text-sm font-medium text-slate-600 hover:text-blue-600 transition-colors">Pricing</a>
          <button className="bg-blue-600 text-white px-5 py-2.5 rounded-full text-sm font-semibold hover:bg-blue-700 transition-all shadow-lg shadow-blue-200">
            Book a Demo
          </button>
        </div>

        <button className="md:hidden p-2 text-slate-600" onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
          {isMobileMenuOpen ? <X /> : <Menu />}
        </button>
      </div>

      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-white border-t border-slate-100 overflow-hidden"
          >
            <div className="px-4 py-6 flex flex-col gap-4">
              <a href="#problem" onClick={() => setIsMobileMenuOpen(false)} className="text-lg font-medium text-slate-600">Problem</a>
              <a href="#solution" onClick={() => setIsMobileMenuOpen(false)} className="text-lg font-medium text-slate-600">Solution</a>
              <a href="#how-it-works" onClick={() => setIsMobileMenuOpen(false)} className="text-lg font-medium text-slate-600">How It Works</a>
              <a href="#features" onClick={() => setIsMobileMenuOpen(false)} className="text-lg font-medium text-slate-600">Features</a>
              <a href="#integrations" onClick={() => setIsMobileMenuOpen(false)} className="text-lg font-medium text-slate-600">Integrations</a>
              <button className="bg-blue-600 text-white px-5 py-3 rounded-xl text-center font-semibold">
                Book a Demo
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

const Hero = () => {
  return (
    <section className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 overflow-hidden">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full -z-10 opacity-30">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-blue-200 rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-slate-200 rounded-full blur-3xl" />
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 text-blue-700 text-xs font-bold uppercase tracking-wider mb-6">
              <BarChart3 className="w-3.5 h-3.5" />
              Built for Concrete Pumping Companies
            </div>
            <h1 className="text-5xl lg:text-7xl font-bold text-slate-900 leading-[1.1] mb-6">
              Never Miss Another <span className="text-blue-600">Concrete Pumping</span> Job
            </h1>
            <p className="text-xl text-slate-600 mb-10 max-w-lg leading-relaxed">
              Pump Time AI answers calls, books jobs, and helps keep your schedule full Monday through Saturday—even while you're on the job site.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <button className="bg-blue-600 text-white px-8 py-4 rounded-xl text-lg font-bold hover:bg-blue-700 transition-all shadow-xl shadow-blue-200 flex items-center justify-center gap-2">
                Get Started Now <ArrowRight className="w-5 h-5" />
              </button>
              <button className="bg-white text-slate-900 border-2 border-slate-200 px-8 py-4 rounded-xl text-lg font-bold hover:bg-slate-50 transition-all flex items-center justify-center gap-2">
                Hear the Demo
              </button>
            </div>
            <div className="mt-10 flex items-center gap-4 text-sm text-slate-500">
              <div className="flex -space-x-2">
                {[1, 2, 3, 4].map((i) => (
                  <img 
                    key={i} 
                    src={`https://picsum.photos/seed/user${i}/100/100`} 
                    className="w-8 h-8 rounded-full border-2 border-white" 
                    alt="User"
                    referrerPolicy="no-referrer"
                  />
                ))}
              </div>
              <span>Trusted by 50+ Concrete Contractors</span>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="relative"
          >
            <div className="relative z-10 bg-white rounded-3xl shadow-2xl border border-slate-100 p-6 lg:p-8">
              <div className="flex items-center justify-between mb-8">
                <div>
                  <h3 className="text-lg font-bold text-slate-900">Today's Schedule</h3>
                  <p className="text-sm text-slate-500">Monday, March 9, 2026</p>
                </div>
                <div className="bg-blue-50 text-blue-600 px-3 py-1 rounded-lg text-xs font-bold uppercase">
                  Live Feed
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-center gap-4 p-4 bg-blue-50 rounded-2xl border border-blue-100">
                  <div className="w-12 h-12 bg-blue-600 rounded-xl flex items-center justify-center text-white font-bold">7A</div>
                  <div className="flex-1">
                    <h4 className="font-bold text-slate-900">Residential Pour - 45 Yards</h4>
                    <p className="text-sm text-slate-600">123 Construction Way, Dallas</p>
                  </div>
                  <CheckCircle2 className="text-blue-600 w-6 h-6" />
                </div>

                <div className="flex items-center gap-4 p-4 bg-slate-50 rounded-2xl border border-slate-100 opacity-60">
                  <div className="w-12 h-12 bg-slate-400 rounded-xl flex items-center justify-center text-white font-bold">1P</div>
                  <div className="flex-1">
                    <h4 className="font-bold text-slate-900">Driveway Extension</h4>
                    <p className="text-sm text-slate-600">456 Suburban Lane, Plano</p>
                  </div>
                  <Clock className="text-slate-400 w-6 h-6" />
                </div>

                <div className="pt-4 border-t border-slate-100">
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-sm font-bold text-slate-900">New Booking via AI Receptionist</span>
                    <span className="text-xs text-slate-400">2 mins ago</span>
                  </div>
                  <div className="flex items-center gap-3 text-sm text-slate-600">
                    <PhoneCall className="w-4 h-4 text-green-500" />
                    <span>Incoming call from (555) 012-3456</span>
                  </div>
                  <div className="mt-2 bg-slate-900 text-white p-3 rounded-xl text-xs font-mono">
                    AI: "I have a 7:00 AM slot available this Wednesday. Would you like to book that for your 30-yard pour?"
                  </div>
                </div>
              </div>
            </div>
            {/* Decorative elements */}
            <div className="absolute -top-6 -right-6 w-24 h-24 bg-blue-600 rounded-full -z-10 opacity-10 blur-xl" />
            <div className="absolute -bottom-10 -left-10 w-40 h-40 bg-slate-900 rounded-full -z-10 opacity-5 blur-2xl" />
          </motion.div>
        </div>
      </div>
    </section>
  );
};

const Problem = () => {
  const problems = [
    {
      icon: <PhoneCall className="w-6 h-6 text-red-500" />,
      title: "Missed Calls on Site",
      desc: "You're on the pump or in the truck. You can't answer every call, and customers won't leave a voicemail—they'll just call your competitor."
    },
    {
      icon: <Calendar className="w-6 h-6 text-red-500" />,
      title: "Manual Scheduling Headaches",
      desc: "Trying to remember who called for what day while you're covered in concrete leads to double-bookings and forgotten jobs."
    },
    {
      icon: <TrendingUp className="w-6 h-6 text-red-500" />,
      title: "Lost Revenue",
      desc: "Every missed call is a missed $500 to $1,500+ job. Over a month, that's thousands of dollars leaking out of your business."
    },
    {
      icon: <Star className="w-6 h-6 text-red-500" />,
      title: "Weak Online Presence",
      desc: "Busy crews forget to ask for reviews. Without a steady stream of 5-star Google reviews, you're losing the trust of new local customers."
    }
  ];

  return (
    <section id="problem" className="py-24 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-sm font-bold text-blue-600 uppercase tracking-widest mb-3">The Problem</h2>
          <h3 className="text-4xl font-bold text-slate-900 mb-4">Concrete Pumping is Hard Enough.</h3>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto">
            Don't let missed phone calls and manual scheduling be the reason your business stops growing.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {problems.map((p, i) => (
            <motion.div 
              key={i}
              whileHover={{ y: -5 }}
              className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100"
            >
              <div className="bg-red-50 w-12 h-12 rounded-2xl flex items-center justify-center mb-6">
                {p.icon}
              </div>
              <h4 className="text-xl font-bold text-slate-900 mb-3">{p.title}</h4>
              <p className="text-slate-600 leading-relaxed">{p.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Solution = () => {
  return (
    <section id="solution" className="py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div className="order-2 lg:order-1">
            <img 
              src="https://picsum.photos/seed/concrete-pump/800/600" 
              className="rounded-3xl shadow-2xl" 
              alt="Concrete Pumping Solution"
              referrerPolicy="no-referrer"
            />
          </div>
          <div className="order-1 lg:order-2">
            <h2 className="text-sm font-bold text-blue-600 uppercase tracking-widest mb-3">The Solution</h2>
            <h3 className="text-4xl font-bold text-slate-900 mb-6">Your 24/7 AI Receptionist That Actually Knows Concrete.</h3>
            <p className="text-lg text-slate-600 mb-8 leading-relaxed">
              Pump Time AI isn't just a generic answering service. It's a specialized system built to handle the unique needs of concrete contractors.
            </p>
            
            <ul className="space-y-4">
              {[
                "Answers every call instantly, 24/7",
                "Asks for address, pour type, and yardage",
                "Offers 7:00 AM or 1:00 PM slots automatically",
                "Sends instant SMS confirmations to you and the customer",
                "Automatically requests Google reviews after the job"
              ].map((item, i) => (
                <li key={i} className="flex items-start gap-3">
                  <div className="mt-1 bg-blue-100 p-1 rounded-full">
                    <CheckCircle2 className="w-4 h-4 text-blue-600" />
                  </div>
                  <span className="text-slate-700 font-medium">{item}</span>
                </li>
              ))}
            </ul>

            <button className="mt-10 bg-slate-900 text-white px-8 py-4 rounded-xl font-bold hover:bg-slate-800 transition-all flex items-center gap-2">
              See the Full Feature List <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

const HowItWorks = () => {
  const steps = [
    {
      num: "01",
      title: "Customer Calls",
      desc: "A prospect calls your business line. If you don't answer within 2 rings, Pump Time AI picks up professionally."
    },
    {
      num: "02",
      title: "AI Collects Details",
      desc: "The AI asks for the job address, type of pour (residential/commercial), and estimated yardage."
    },
    {
      num: "03",
      title: "Job is Booked",
      desc: "The AI checks your schedule and offers a 7 AM or 1 PM slot. Once confirmed, it's added to your calendar."
    },
    {
      num: "04",
      title: "You Get Notified",
      desc: "You receive an instant SMS with all the job details. No more scribbling on napkins or checking call logs."
    }
  ];

  return (
    <section id="how-it-works" className="py-24 bg-slate-900 text-white overflow-hidden relative">
      <div className="absolute top-0 right-0 w-1/2 h-full bg-blue-600/10 skew-x-12 translate-x-1/2" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-20">
          <h2 className="text-sm font-bold text-blue-400 uppercase tracking-widest mb-3">Process</h2>
          <h3 className="text-4xl font-bold mb-4">How It Works</h3>
          <p className="text-slate-400 max-w-xl mx-auto">
            Four simple steps to automate your booking and stop missing revenue.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12">
          {steps.map((s, i) => (
            <div key={i} className="relative">
              <div className="text-6xl font-black text-white/5 absolute -top-8 -left-4 select-none">{s.num}</div>
              <h4 className="text-xl font-bold mb-4 relative z-10">{s.title}</h4>
              <p className="text-slate-400 leading-relaxed">{s.desc}</p>
              {i < steps.length - 1 && (
                <div className="hidden lg:block absolute top-6 -right-6 w-12 h-[1px] bg-slate-700" />
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Features = () => {
  const features = [
    {
      icon: <PhoneCall className="w-6 h-6" />,
      title: "24/7 AI Receptionist",
      desc: "Never let a call go to voicemail again. Our AI is always awake and ready to book."
    },
    {
      icon: <MessageSquare className="w-6 h-6" />,
      title: "Concrete-Specific Intake",
      desc: "We ask the right questions: mix type, yardage, pump distance, and site access."
    },
    {
      icon: <Calendar className="w-6 h-6" />,
      title: "Smart Booking Logic",
      desc: "Optimized for 7 AM and 1 PM slots to maximize your crew's efficiency."
    },
    {
      icon: <Smartphone className="w-6 h-6" />,
      title: "SMS Confirmations",
      desc: "Instant texts to you and your customer so everyone is on the same page."
    },
    {
      icon: <Star className="w-6 h-6" />,
      title: "Review Automation",
      desc: "Automatically text customers for a Google review 2 hours after the job is done."
    },
    {
      icon: <ShieldCheck className="w-6 h-6" />,
      title: "Google Business Support",
      desc: "We help optimize your profile to ensure you're the first choice in local search."
    }
  ];

  return (
    <section id="features" className="py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-sm font-bold text-blue-600 uppercase tracking-widest mb-3">Features</h2>
          <h3 className="text-4xl font-bold text-slate-900 mb-4">Everything You Need to Scale.</h3>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((f, i) => (
            <div key={i} className="p-8 rounded-3xl border border-slate-100 hover:border-blue-200 hover:shadow-xl hover:shadow-blue-50 transition-all group">
              <div className="bg-slate-50 w-14 h-14 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-blue-600 group-hover:text-white transition-all">
                {f.icon}
              </div>
              <h4 className="text-xl font-bold text-slate-900 mb-3">{f.title}</h4>
              <p className="text-slate-600 leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Integrations = () => {
  const integrations = [
    { name: "Jobber", category: "Field Service Management" },
    { name: "ServiceTitan", category: "Operations Software" },
    { name: "Housecall Pro", category: "Scheduling & CRM" },
    { name: "Google Calendar", category: "Scheduling" },
    { name: "Outlook", category: "Scheduling" },
    { name: "QuickBooks", category: "Accounting" }
  ];

  return (
    <section id="integrations" className="py-24 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div>
            <h2 className="text-sm font-bold text-blue-600 uppercase tracking-widest mb-3">Integrations</h2>
            <h3 className="text-4xl font-bold text-slate-900 mb-6">Connects with the Tools You Already Use.</h3>
            <p className="text-lg text-slate-600 mb-8 leading-relaxed">
              Pump Time AI doesn't live on an island. It connects directly to your existing CRM and scheduling software to ensure your data is always unified and your workflows are automated.
            </p>

            <div className="space-y-6">
              <div className="flex gap-4">
                <div className="bg-blue-100 p-3 rounded-2xl h-fit">
                  <Zap className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 mb-1">Automated Workflows</h4>
                  <p className="text-slate-600">Jobs booked by AI are instantly pushed to your field service software, triggering your existing dispatch workflows.</p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="bg-blue-100 p-3 rounded-2xl h-fit">
                  <Database className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 mb-1">Unified Customer Data</h4>
                  <p className="text-slate-600">Customer details, job history, and site notes are synced across platforms, eliminating manual data entry errors.</p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="bg-blue-100 p-3 rounded-2xl h-fit">
                  <RefreshCw className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 mb-1">Real-Time Sync</h4>
                  <p className="text-slate-600">Our system checks your live calendar availability before offering slots, ensuring you never get double-booked.</p>
                </div>
              </div>
            </div>
          </div>

          <div className="relative">
            <div className="grid grid-cols-2 gap-4">
              {integrations.map((int, i) => (
                <motion.div 
                  key={i}
                  initial={{ opacity: 0, y: 10 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.1 }}
                  className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm flex flex-col items-center text-center group hover:border-blue-200 hover:shadow-md transition-all"
                >
                  <div className="w-12 h-12 bg-slate-50 rounded-xl mb-4 flex items-center justify-center group-hover:bg-blue-50 transition-colors">
                    <Link className="w-6 h-6 text-slate-400 group-hover:text-blue-600" />
                  </div>
                  <h5 className="font-bold text-slate-900">{int.name}</h5>
                  <p className="text-xs text-slate-500 mt-1">{int.category}</p>
                </motion.div>
              ))}
            </div>
            {/* Connection lines visual effect */}
            <div className="absolute inset-0 -z-10 flex items-center justify-center">
              <div className="w-full h-full border-2 border-dashed border-slate-200 rounded-full opacity-20 animate-pulse" />
            </div>
          </div>
        </div>

        <div className="mt-20 p-8 bg-white rounded-[2rem] border border-slate-100 shadow-sm text-center">
          <h4 className="text-xl font-bold text-slate-900 mb-4">Simple Integration Process</h4>
          <div className="flex flex-col md:flex-row justify-center items-center gap-8 md:gap-16">
            <div className="flex flex-col items-center">
              <div className="w-10 h-10 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold mb-3">1</div>
              <span className="text-sm font-medium text-slate-600">Connect Account</span>
            </div>
            <ArrowRight className="hidden md:block w-5 h-5 text-slate-300" />
            <div className="flex flex-col items-center">
              <div className="w-10 h-10 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold mb-3">2</div>
              <span className="text-sm font-medium text-slate-600">Map Fields</span>
            </div>
            <ArrowRight className="hidden md:block w-5 h-5 text-slate-300" />
            <div className="flex flex-col items-center">
              <div className="w-10 h-10 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold mb-3">3</div>
              <span className="text-sm font-medium text-slate-600">Go Live</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const ROI = () => {
  return (
    <section className="py-24 bg-blue-600 text-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div>
            <h3 className="text-4xl font-bold mb-6 leading-tight">One Missed Call is a <span className="underline decoration-blue-300">$1,000</span> Mistake.</h3>
            <p className="text-xl text-blue-100 mb-10 leading-relaxed">
              For most concrete pumping companies, booking just ONE extra job per week pays for Pump Time AI for the entire year.
            </p>
            
            <div className="space-y-6">
              <div className="bg-white/10 backdrop-blur-md p-6 rounded-2xl border border-white/20">
                <div className="text-3xl font-bold mb-1">$52,000+</div>
                <p className="text-blue-100 text-sm">Potential annual revenue from just 1 extra job/week</p>
              </div>
              <div className="bg-white/10 backdrop-blur-md p-6 rounded-2xl border border-white/20">
                <div className="text-3xl font-bold mb-1">100%</div>
                <p className="text-blue-100 text-sm">Of calls answered, even when you're covered in concrete</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-3xl p-8 text-slate-900 shadow-2xl">
            <h4 className="text-2xl font-bold mb-6">The Math is Simple</h4>
            <div className="space-y-4 mb-8">
              <div className="flex justify-between items-center py-3 border-b border-slate-100">
                <span className="text-slate-600">Average Job Value</span>
                <span className="font-bold">$850</span>
              </div>
              <div className="flex justify-between items-center py-3 border-b border-slate-100">
                <span className="text-slate-600">Missed Calls Per Week</span>
                <span className="font-bold text-red-500">3 - 5</span>
              </div>
              <div className="flex justify-between items-center py-3 border-b border-slate-100">
                <span className="text-slate-600">Lost Revenue Per Month</span>
                <span className="font-bold text-red-600">$10,000+</span>
              </div>
              <div className="flex justify-between items-center py-3 bg-blue-50 px-4 rounded-xl">
                <span className="font-bold text-blue-900">Pump Time AI Cost</span>
                <span className="font-bold text-blue-600">Fraction of 1 Job</span>
              </div>
            </div>
            <button className="w-full bg-blue-600 text-white py-4 rounded-xl font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-100">
              Calculate Your ROI
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

const UseCase = () => {
  return (
    <section className="py-24 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-sm font-bold text-blue-600 uppercase tracking-widest mb-3">Real Scenario</h2>
          <h3 className="text-4xl font-bold text-slate-900 mb-4">A Typical Booking with Pump Time AI</h3>
        </div>

        <div className="max-w-3xl mx-auto space-y-6">
          <div className="flex gap-4 items-start">
            <div className="w-10 h-10 rounded-full bg-slate-200 flex-shrink-0 flex items-center justify-center font-bold">C</div>
            <div className="bg-white p-4 rounded-2xl rounded-tl-none shadow-sm border border-slate-100">
              <p className="text-slate-700 italic">"Hey, I need a pump for a residential pour this Wednesday. Do you have anything open?"</p>
            </div>
          </div>

          <div className="flex gap-4 items-start flex-row-reverse">
            <div className="w-10 h-10 rounded-full bg-blue-600 text-white flex-shrink-0 flex items-center justify-center font-bold">AI</div>
            <div className="bg-blue-600 p-4 rounded-2xl rounded-tr-none shadow-md text-white">
              <p>"I can certainly help with that. What's the address for the pour, and roughly how many yards are we looking at?"</p>
            </div>
          </div>

          <div className="flex gap-4 items-start">
            <div className="w-10 h-10 rounded-full bg-slate-200 flex-shrink-0 flex items-center justify-center font-bold">C</div>
            <div className="bg-white p-4 rounded-2xl rounded-tl-none shadow-sm border border-slate-100">
              <p className="text-slate-700 italic">"It's 742 Evergreen Terrace. About 25 yards for a back patio."</p>
            </div>
          </div>

          <div className="flex gap-4 items-start flex-row-reverse">
            <div className="w-10 h-10 rounded-full bg-blue-600 text-white flex-shrink-0 flex items-center justify-center font-bold">AI</div>
            <div className="bg-blue-600 p-4 rounded-2xl rounded-tr-none shadow-md text-white">
              <p>"Perfect. I have a 7:00 AM slot available this Wednesday, March 11th. Would you like to lock that in?"</p>
            </div>
          </div>

          <div className="flex gap-4 items-start">
            <div className="w-10 h-10 rounded-full bg-slate-200 flex-shrink-0 flex items-center justify-center font-bold">C</div>
            <div className="bg-white p-4 rounded-2xl rounded-tl-none shadow-sm border border-slate-100">
              <p className="text-slate-700 italic">"Yes, let's do it."</p>
            </div>
          </div>

          <div className="mt-8 bg-green-50 border border-green-100 p-6 rounded-3xl flex items-center gap-4">
            <div className="bg-green-500 p-2 rounded-xl text-white">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-bold text-green-900">Job Booked & Confirmed</h4>
              <p className="text-green-700 text-sm">SMS sent to customer and owner instantly.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const ProspectSpecific = () => {
  return (
    <section className="py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-slate-900 rounded-[3rem] p-12 lg:p-20 text-white relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-blue-600 rounded-full blur-[120px] opacity-20" />
          
          <div className="max-w-3xl relative z-10">
            <h3 className="text-4xl font-bold mb-8">Why This Works for Small Concrete Pumping Companies</h3>
            <div className="grid sm:grid-cols-2 gap-8">
              <div>
                <h4 className="text-xl font-bold mb-3 text-blue-400">No Receptionist Needed</h4>
                <p className="text-slate-400 leading-relaxed">
                  Most small operators can't justify a full-time office person. Pump Time AI gives you that professional front for a fraction of the cost.
                </p>
              </div>
              <div>
                <h4 className="text-xl font-bold mb-3 text-blue-400">Focus on the Pour</h4>
                <p className="text-slate-400 leading-relaxed">
                  Stop pulling your phone out while you're operating the boom. Focus on safety and quality while the AI handles the logistics.
                </p>
              </div>
              <div>
                <h4 className="text-xl font-bold mb-3 text-blue-400">Professional Image</h4>
                <p className="text-slate-400 leading-relaxed">
                  Customers trust companies that answer the phone and send professional confirmations. Stand out from the "one-man-show" competitors.
                </p>
              </div>
              <div>
                <h4 className="text-xl font-bold mb-3 text-blue-400">Scale Without Stress</h4>
                <p className="text-slate-400 leading-relaxed">
                  As you add more trucks, the AI scales with you. It handles multiple calls at once, something a human receptionist struggles with.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const Pricing = () => {
  return (
    <section id="pricing" className="py-24 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-sm font-bold text-blue-600 uppercase tracking-widest mb-3">Pricing</h2>
          <h3 className="text-4xl font-bold text-slate-900 mb-4">Simple, Transparent Pricing.</h3>
          <p className="text-lg text-slate-600 max-w-xl mx-auto">
            Positioned as a business solution that pays for itself, not just another software tool.
          </p>
        </div>

        <div className="max-w-lg mx-auto bg-white rounded-3xl shadow-xl border border-slate-100 overflow-hidden">
          <div className="p-10 text-center border-b border-slate-100">
            <h4 className="text-2xl font-bold text-slate-900 mb-2">The Pumper Plan</h4>
            <p className="text-slate-500 mb-6">Everything you need to automate your bookings.</p>
            <div className="flex items-center justify-center gap-1">
              <span className="text-4xl font-bold text-slate-900">$499</span>
              <span className="text-slate-500">/month</span>
            </div>
            <p className="text-xs text-slate-400 mt-2">+ One-time $699 setup fee</p>
          </div>
          <div className="p-10 bg-slate-50/50">
            <ul className="space-y-4 mb-10">
              {[
                "24/7 AI Receptionist",
                "Automated 7AM/1PM Booking",
                "SMS Job Confirmations",
                "Google Review Automation",
                "Lead Dashboard Access",
                "Custom Intake Questions"
              ].map((item, i) => (
                <li key={i} className="flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 text-green-500" />
                  <span className="text-slate-700 font-medium">{item}</span>
                </li>
              ))}
            </ul>
            <button className="w-full bg-blue-600 text-white py-4 rounded-xl font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-100">
              Book Your Setup Call
            </button>
            <p className="text-center text-xs text-slate-400 mt-4">
              Custom pricing available for fleets with 5+ trucks.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

const CTA = () => {
  return (
    <section className="py-24 relative overflow-hidden">
      <div className="absolute inset-0 bg-blue-600 -z-10" />
      <div className="absolute top-0 left-0 w-full h-full opacity-10 -z-10">
        <div className="absolute top-0 left-0 w-64 h-64 bg-white rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-white rounded-full blur-3xl" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-white">
        <h3 className="text-4xl lg:text-5xl font-bold mb-6">Ready to Hear Pump Time AI in Action?</h3>
        <p className="text-xl text-blue-100 mb-10 max-w-2xl mx-auto leading-relaxed">
          Stop wondering how many jobs you're missing. See how our AI can transform your concrete pumping business today.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <button className="bg-white text-blue-600 px-10 py-5 rounded-2xl text-xl font-bold hover:bg-blue-50 transition-all shadow-2xl">
            Book a Demo
          </button>
          <button className="bg-blue-700 text-white border border-blue-400 px-10 py-5 rounded-2xl text-xl font-bold hover:bg-blue-800 transition-all">
            Call the Demo Line
          </button>
        </div>
      </div>
    </section>
  );
};

const Footer = () => {
  return (
    <footer className="bg-slate-900 text-white pt-20 pb-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          <div className="lg:col-span-2">
            <div className="flex items-center gap-2 mb-6">
              <div className="bg-blue-600 p-1.5 rounded-lg">
                <TrendingUp className="text-white w-6 h-6" />
              </div>
              <span className="text-2xl font-bold tracking-tight">Pump Time <span className="text-blue-600">AI</span></span>
            </div>
            <p className="text-slate-400 max-w-md leading-relaxed mb-8">
              The AI-powered growth engine for concrete pumping companies. We answer the calls you miss, book the jobs you want, and automate the reviews you need.
            </p>
            <div className="flex gap-4">
              <div className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center hover:bg-blue-600 transition-all cursor-pointer">
                <Smartphone className="w-5 h-5" />
              </div>
              <div className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center hover:bg-blue-600 transition-all cursor-pointer">
                <MessageSquare className="w-5 h-5" />
              </div>
            </div>
          </div>

          <div>
            <h4 className="font-bold mb-6">Quick Links</h4>
            <ul className="space-y-4 text-slate-400">
              <li><a href="#problem" className="hover:text-white transition-colors">Problem</a></li>
              <li><a href="#solution" className="hover:text-white transition-colors">Solution</a></li>
              <li><a href="#how-it-works" className="hover:text-white transition-colors">How It Works</a></li>
              <li><a href="#features" className="hover:text-white transition-colors">Features</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold mb-6">Contact</h4>
            <ul className="space-y-4 text-slate-400">
              <li className="flex items-center gap-3">
                <PhoneCall className="w-4 h-4 text-blue-500" />
                <span>(555) 123-4567</span>
              </li>
              <li className="flex items-center gap-3">
                <MessageSquare className="w-4 h-4 text-blue-500" />
                <span>hello@pumptime.ai</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="pt-8 border-t border-slate-800 flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-slate-500">
          <p>© 2026 Pump Time AI. All rights reserved.</p>
          <div className="flex gap-8">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

// --- Main App ---

export default function App() {
  return (
    <div className="min-h-screen font-sans selection:bg-blue-100 selection:text-blue-900">
      <Navbar />
      <main>
        <Hero />
        <Problem />
        <Solution />
        <HowItWorks />
        <Features />
        <Integrations />
        <ROI />
        <UseCase />
        <ProspectSpecific />
        <Pricing />
        <CTA />
      </main>
      <Footer />
    </div>
  );
}
